<?php

return array(
    'auth'  => 'auth',   // Add an auth route in your APPPATH/config/routes.php
);