<p style="font-size: 18px;">Hi <?php echo $username;?>!</p>

<p>Your account has been locked due to an excessive amount of unsuccessful sign in attempts.</p>

<p>Click the link below to unlock your account:</p>

<p>
    <a href="<?php echo $uri; ?>">
        Unlock my account
    </a>
</p>