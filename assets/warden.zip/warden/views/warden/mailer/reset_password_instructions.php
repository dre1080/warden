<p style="font-size: 18px;">Hi <?php echo $username;?>!</p>

<p>Someone has requested a link to change your password, and you can do this through the link below:</p>

<p>
    <a href="<?php echo $uri; ?>">
        Change my password
    </a>
</p

<p>If you didn't request this, please ignore this email.</p>
<p>Your password won't change until you access the link above and create a new one.</p>
