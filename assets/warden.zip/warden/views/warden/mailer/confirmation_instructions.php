<p style="font-size: 18px;">Hi <?php echo $username;?>!</p>

<p>You can confirm your account through the link below:</p>

<p>
    <a href="<?php echo $uri; ?>">
        Confirm my account
    </a>
</p>